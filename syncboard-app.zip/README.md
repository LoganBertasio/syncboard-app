# SyncBoard MVP
This is the starting point for your SyncBoard SaaS app.